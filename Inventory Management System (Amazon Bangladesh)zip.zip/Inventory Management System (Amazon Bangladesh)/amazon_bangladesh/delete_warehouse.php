<?php
session_start();
include('includes/db.php');

// Check admin login
if (!isset($_SESSION['role']) || $_SESSION['role'] !== 'admin') {
    header('Location: index.php'); // Redirect if not admin
    exit;
}

// Check if the warehouse ID is provided
if (!isset($_GET['id'])) {
    header('Location: warehouse_management.php'); // Redirect if no warehouse ID is provided
    exit;
}

$warehouse_id = $_GET['id'];

// Delete the warehouse from the database
$query = "DELETE FROM warehouses WHERE WarehouseID = ?";
$stmt = $conn->prepare($query);
$stmt->bind_param("i", $warehouse_id);
$stmt->execute();

if ($stmt->affected_rows > 0) {
    header('Location: warehouse_management.php'); // Redirect to warehouse management
    exit;
} else {
    echo "Error deleting warehouse: " . $conn->error;
}

$stmt->close();
$conn->close();
?>