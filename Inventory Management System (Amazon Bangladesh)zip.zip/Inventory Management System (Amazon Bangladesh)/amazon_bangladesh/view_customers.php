<?php
// view_customers.php
session_start(); // Start the session
include('includes/db.php'); // Include the database connection

// Check if the user is logged in as an admin
if (!isset($_SESSION['role']) || $_SESSION['role'] !== 'admin') {
    header('Location: index.php'); // Redirect to login page if not an admin
    exit;
}

// Fetch customers from the database
$query = "SELECT * FROM Customers";
$result = $conn->query($query);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Manage Customers - Amazon Bangladesh</title>
    <link rel="stylesheet" href="css/style.css"> <!-- Link to your CSS file -->
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f4f4f4;
            margin: 0;
            padding: 20px;
        }
        header {
            background: #007BFF;
            color: white;
            padding: 10px 20px;
            text-align: center;
        }
        nav ul {
            list-style: none;
            padding: 0;
        }
        nav ul li {
            display: inline;
            margin-right: 15px;
        }
        nav ul li a {
            color: white;
            text-decoration: none;
        }
        main {
            margin-top: 20px;
            padding: 20px;
            background: white;
            border-radius: 5px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
        }
        table {
            width: 100%;
            border-collapse: collapse;
        }
        table, th, td {
            border: 1px solid #ddd;
        }
        th, td {
            padding: 8px;
            text-align: left;
        }
        th {
            background-color: #007BFF;
            color: white;
        }
        footer {
            text-align: center;
            margin-top: 20px;
            font-size: 0.9em;
        }
        .add-customer-btn {
            margin-bottom: 20px;
            display: inline-block;
            padding: 10px 15px;
            background-color: #28a745;
            color: white;
            text-decoration: none;
            border-radius: 5px;
        }
        .add-customer-btn:hover {
            background-color: #218838;
        }
    </style>
</head>
<body>
    <header>
        <h1>Manage Customers</h1>
        <nav>
            <ul>
                <li><a href="admin_dashboard.php">Dashboard</a></li>
                <li><a href="view_orders.php">View Orders</a></li>
                <li><a href="view_suppliers.php">Manage Suppliers</a></li>
                <li><a href="view_warehouse.php">Manage Warehouse</a></li>
                <li><a href="view_categories.php">Manage Categories</a></li>
                <li><a href="logout.php">Logout</a></li>
            </ul>
        </nav>
    </header>

    <main>
        <div class="customer-listing-container">
            <a href="add_customer.php" class="add-customer-btn">Add New Customer</a> <!-- Link to add customer page -->
            <?php if ($result->num_rows > 0): ?>
                <table>
                    <thead>
                        <tr>
                            <th>Customer ID</th>
                            <th>Customer Name</th>
                            <th>Email</th>
                            <th>Contact Name</th>
                            <th>Address</th>
                            <th>City</th>
                            <th>Postal Code</th>
                            <th>Country</th>
                            <th>Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php while ($row = $result->fetch_assoc()): ?>
                            <tr>
                                <td><?php echo $row['CustomerID']; ?></td>
                                <td><?php echo $row['CustomerName']; ?></td>
                                <td><?php echo $row['Email']; ?></td>
                                <td><?php echo $row['ContactName']; ?></td>
                                <td><?php echo $row['Address']; ?></td>
                                <td><? ```php
                                echo $row['City']; ?></td>
                                <td><?php echo $row['PostalCode']; ?></td>
                                <td><?php echo $row['Country']; ?></td>
                                <td>
                                    <a href="edit_customer.php?id=<?php echo $row['CustomerID']; ?>">Edit</a> | 
                                    <a href="delete_customer.php?id=<?php echo $row['CustomerID']; ?>" onclick="return confirm('Are you sure you want to delete this customer?');">Delete</a>
                                </td>
                            </tr>
                        <?php endwhile; ?>
                    </tbody>
                </table>
            <?php else: ?>
                <p>No customers found.</p>
            <?php endif; ?>
        </div>
    </main>

    <footer>
        <p>&copy; <?php echo date("Y"); ?> Amazon Bangladesh. All rights reserved.</p>
    </footer>
</body>
</html>