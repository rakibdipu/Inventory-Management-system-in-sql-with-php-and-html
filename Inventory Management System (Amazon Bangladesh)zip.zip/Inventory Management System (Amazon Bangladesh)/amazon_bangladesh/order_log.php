<?php
session_start();
include('includes/db.php');

// Check admin login
if (!isset($_SESSION['role']) || $_SESSION['role'] !== 'admin') {
    header('Location: index.php'); // Redirect if not admin
    exit;
}

// Fetch all order logs
$query = "SELECT * FROM orderlog";
$result = $conn->query($query);

// Check for errors in the query
if (!$result) {
    die("Database query failed: " . $conn->error);
}

include('includes/header.php');
?>

<div class="order-log">
    <h1>Order Log</h1>
    <table>
        <thead>
            <tr>
                <th>Log ID</th>
                <th>Order ID</th>
                <th>Action</th>
                <th>Date</th>
            </tr>
        </thead>
        <tbody>
            <?php while ($log = $result->fetch_assoc()): ?>
                <tr>
                    <td><?= htmlspecialchars($log['LogID']); ?></td>
                    <td><?= htmlspecialchars($log['OrderID']); ?></td>
                    <td><?= htmlspecialchars($log['Action']); ?></td>
                    <td><?= htmlspecialchars($log['Date']); ?></td>
                </tr>
            <?php endwhile; ?>
        </tbody>
    </table>
</div>

<?php include('includes/footer.php'); ?>