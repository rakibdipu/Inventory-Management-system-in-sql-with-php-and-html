<?php
session_start();
include('includes/db.php');

// Check customer login
if (!isset($_SESSION['role']) || $_SESSION['role'] !== 'customer') {
    header('Location: index.php'); // Redirect if not customer
    exit;
}

// Fetch transaction history for the logged-in customer
$query = "SELECT t.TransactionID, t.OrderID, t.Amount, t.Date, o.Status 
          FROM transactions t 
          JOIN orders o ON t.OrderID = o.OrderID 
          WHERE o.CustomerID = ?";
$stmt = $conn->prepare($query);
$stmt->bind_param("i", $_SESSION['customer_id']);
$stmt->execute();
$result = $stmt->get_result();

include('includes/header.php');
?>

<div class="transaction-history">
    <h1>Your Transaction History</h1>
    <table>
        <thead>
            <tr>
                <th>Transaction ID</th>
                <th>Order ID</th>
                <th>Amount</th>
                <th>Date</th>
                <th>Status</th>
            </tr>
        </thead>
        <tbody>
            <?php while ($transaction = $result->fetch_assoc()): ?>
                <tr>
                    <td><?= htmlspecialchars($transaction['TransactionID']); ?></td>
                    <td><?= htmlspecialchars($transaction['OrderID']); ?></td>
                    <td><?= htmlspecialchars($transaction['Amount']); ?></td>
                    <td><?= htmlspecialchars($transaction['Date']); ?></td>
                    <td><?= htmlspecialchars($transaction['Status']); ?></td>
                </tr>
            <?php endwhile; ?>
        </tbody>
    </table>
</div>

<?php include('includes/footer.php'); ?>