<?php
session_start();
include('includes/db.php'); // Include the database connection

// Check if the user is an admin
if (!isset($_SESSION['role']) || $_SESSION['role'] !== 'admin') {
    header('Location: index.php');
    exit;
}

// Delete customer
if (isset($_GET['id'])) {
    $customerID = $_GET['id'];

    $query = "DELETE FROM Customers WHERE CustomerID = ?";
    $stmt = $conn->prepare($query);
    $stmt->bind_param("i", $customerID);

    if ($stmt->execute()) {
        header('Location: view_customers.php?message=Customer deleted successfully');
        exit;
    } else {
        echo "Error deleting customer: " . $conn->error;
    }
} else {
    header('Location: view_customers.php?error=No customer ID provided');
    exit;
}
?>
