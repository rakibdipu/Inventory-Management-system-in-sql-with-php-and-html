<?php
session_start();
include('includes/db.php');

// Check admin login
if (!isset($_SESSION['role']) || $_SESSION['role'] !== 'admin') {
    header('Location: index.php'); // Redirect if not admin
    exit;
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $name = $_POST['name'];
    $price = $_POST['price'];
    $stock = $_POST['stock'];
    $warehouse_id = $_POST['warehouse_id'];

    // Insert new product into the database
    $query = "INSERT INTO products (Name, Price, Stock, WarehouseID) VALUES (?, ?, ?, ?)";
    $stmt = $conn->prepare($query);
    $stmt->bind_param("ssii", $name, $price, $stock, $warehouse_id);
    $stmt->execute();

    if ($stmt->affected_rows > 0) {
        header('Location: inventory_management.php'); // Redirect to inventory management
        exit;
    } else {
        echo "Error adding product: " . $conn->error;
    }
}

$warehouses = $conn->query("SELECT * FROM warehouses"); // Fetch warehouses for dropdown

include('includes/header.php');
?>

<div class="add-inventory">
    <h1>Add New Product</h1>
    <form method="POST" action="">
        <label for="name">Product Name:</label>
        <input type="text" name="name" required>
        <label for="price">Price:</label>
        <input type="text" name="price" required>
        <label for="stock">Stock:</label>
        <input type="number" name="stock" required>
        <label for="warehouse_id">Warehouse:</label>
        <select name="warehouse_id" required>
            <?php while ($warehouse = $warehouses->fetch_assoc()): ?>
                <option value="<?= htmlspecialchars($warehouse['WarehouseID']); ?>"><?= htmlspecialchars($warehouse['Name']); ?></option>
            <?php endwhile; ?>
        </select>
        <button type="submit">Add Product</button>
    </form>
    <a href="inventory_management.php">Back to Inventory Management</a>
</div>

<?php include('includes/footer.php'); ?>