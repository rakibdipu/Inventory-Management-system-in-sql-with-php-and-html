<?php
// view_orders.php
session_start(); // Start the session
include('includes/db.php'); // Include the database connection

// Check if the user is logged in as an admin
if (!isset($_SESSION['role']) || $_SESSION['role'] !== 'admin') {
    header('Location: index.php'); // Redirect to login page if not an admin
    exit;
}

// Handle pagination variables
$limit = 10; // Number of records per page
$page = isset($_GET['page']) ? (int)$_GET['page'] : 1;
$offset = ($page - 1) * $limit;

// Handle search functionality
$search = isset($_GET['search']) ? trim($_GET['search']) : '';
$searchQuery = $search ? "AND (o.OrderID LIKE ? OR c.CustomerName LIKE ?)" : '';

// Handle sorting
$validSortColumns = ['OrderID', 'CustomerName', 'OrderDate', 'TotalAmount']; // Removed 'Status'
$sortColumn = isset($_GET['sort']) && in_array($_GET['sort'], $validSortColumns) ? $_GET['sort'] : 'OrderDate';
$sortOrder = isset($_GET['order']) && $_GET['order'] === 'desc' ? 'DESC' : 'ASC';

// Fetch orders from the database
$query = "SELECT o.OrderID, o.CustomerID, o.OrderDate, o.TotalAmount, c.CustomerName 
          FROM Orders o 
          JOIN Customers c ON o.CustomerID = c.CustomerID 
          WHERE 1=1 $searchQuery
          ORDER BY $sortColumn $sortOrder 
          LIMIT ? OFFSET ?";
$stmt = $conn->prepare($query);

if ($search) {
    $searchParam = "%$search%";
    $stmt->bind_param('sssii', $searchParam, $searchParam, $limit, $offset);
} else {
    $stmt->bind_param('ii', $limit, $offset);
}

$stmt->execute();
$result = $stmt->get_result();

// Get the total number of records for pagination
$totalQuery = "SELECT COUNT(*) AS total FROM Orders o JOIN Customers c ON o.CustomerID = c.CustomerID WHERE 1=1 $searchQuery";
$totalStmt = $conn->prepare($totalQuery);
if ($search) {
    $totalStmt->bind_param('ss', $searchParam, $searchParam);
}
$totalStmt->execute();
$totalResult = $totalStmt->get_result();
$totalRecords = $totalResult->fetch_assoc()['total'];
$totalPages = ceil($totalRecords / $limit);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>View Orders - Amazon Bangladesh</title>
    <link rel="stylesheet" href="css/style.css"> <!-- Link to your CSS file -->
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f4f4f4;
            margin: 0;
            padding: 20px;
        }
        header {
            background: #007BFF;
            color: white;
            padding: 10px 20px;
            text-align: center;
        }
        nav ul {
            list-style: none;
            padding: 0;
        }
        nav ul li {
            display: inline;
            margin-right: 15px;
        }
        nav ul li a {
            color: white;
            text-decoration: none;
        }
        main {
            margin-top: 20px;
            padding: 20px;
            background: white;
            border-radius: 5px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
        }
        table {
            width: 100%;
            border-collapse: collapse;
        }
        table, th, td {
            border: 1px solid #ddd;
        }
        th, td {
            padding: 8px;
            text-align: left;
        }
        th {
            background-color: #007BFF;
            color: white;
        }
        footer {
            text-align: center;
            margin-top: 20px;
            font-size: 0.9em;
        }
        .pagination {
            margin-top: 10px;
            text-align: center;
        }
        .pagination a {
            margin: 0 5px;
            padding: 5px 10px;
            background: #007BFF;
            color: white;
            text-decoration: none;
            border-radius: 3px;
        }
        .pagination a.active {
            background: #0056b3;
        }
        .search-bar {
            margin-bottom: 15px;
        }
        .search-bar input {
            padding: 5px;
            width: 200px;
        }
    </style>
</head>
<body>
    <header>
        <h1>View Orders</h1>
        <nav>
            <ul>
                <li><a href="admin_dashboard.php">Dashboard</a></li>
                <li><a href="view_customers.php">Manage Customers</a></li>
                <li><a href="view_suppliers.php">Manage Suppliers</a></li>
                <li><a href="view_warehouse.php">Manage Warehouse</a></li>
                <li><a href="view_categories.php">Manage Categories</a></li>
                <li><a href="logout.php">Logout</a></li>
            </ul>
        </nav>
    </header>

    <main>
        <div class="search-bar">
            <form method="GET" action="">
                <input type="text" name="search" placeholder="Search by Order ID or Customer Name" value="<?php echo htmlspecialchars($search); ?>">
                <button type="submit">Search</button>
            </form>
        </div>

        <div class="order-listing-container">
            <?php if ($result->num_rows > 0): ?>
                <table>
                    <thead>
                        <tr>
                            <th><a href="?sort=OrderID&order=<?php echo $sortOrder === 'ASC' ? 'desc' : 'asc'; ?>">Order ID</a></th>
                            <th><a href="?sort=CustomerName&order=<?php echo $sortOrder === 'ASC' ? 'desc' : 'asc'; ?>">Customer Name</a></th>
                            <th><a href="?sort=OrderDate&order=<?php echo $sortOrder === 'ASC' ? 'desc' : 'asc'; ?>">Order Date</a></th>
                            <th><a href="?sort=TotalAmount&order=<?php echo $sortOrder === 'ASC' ? 'desc' : 'asc'; ?>">Total Amount</a></th>
                            <!-- Removed Order Status column -->
                            <th>Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php while ($row = $result->fetch_assoc()): ?>
                            <tr>
                                <td><?php echo htmlspecialchars($row['OrderID']); ?></td>
                                <td><?php echo htmlspecialchars($row['CustomerName']); ?></td>
                                <td><?php echo htmlspecialchars($row['OrderDate']); ?></td>
                                <td>$<?php echo number_format($row['TotalAmount'], 2); ?></td>
                                <td>
                                    <a href="view_order_details.php?id=<?php echo $row['OrderID']; ?>">View Details</a>
                                </td>
                            </tr>
                        <?php endwhile; ?>
                    </tbody>
                </table>
            <?php else: ?>
                <p>No orders found.</p>
            <?php endif; ?>
        </div>

        <div class="pagination">
            <?php for ($i = 1; $i <= $totalPages; $i++): ?>
                <a href="?page=<?php echo $i; ?>&search=<?php echo urlencode($search); ?>&sort=<?php echo $sortColumn; ?>&order=<?php echo $sortOrder; ?>" class="<?php echo $i === $page ? 'active' : ''; ?>">
                    <?php echo $i; ?>
                </a>
            <?php endfor; ?>
        </div>
    </main>

    <footer>
        <p>&copy; <?php echo date("Y"); ?> Amazon Bangladesh. All rights reserved.</p>
    </footer>
</body>
</html>
