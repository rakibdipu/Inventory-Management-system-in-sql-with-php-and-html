<?php
session_start();
include('includes/db.php');

// Check admin login
if (!isset($_SESSION['role']) || $_SESSION['role'] !== 'admin') {
    header('Location: index.php'); // Redirect if not admin
    exit;
}

// Fetch all feedback
$query = "SELECT f.FeedbackID, f.Feedback, f.Date, o.OrderID, c.Name AS CustomerName 
          FROM feedback f 
          JOIN orders o ON f.OrderID = o.OrderID 
          JOIN customers c ON o.CustomerID = c.CustomerID";
$result = $conn->query($query);

// Check for errors in the query
if (!$result) {
    die("Database query failed: " . $ conn->error);
}

include('includes/header.php');
?>

<div class="feedback-management">
    <h1>Customer Feedback</h1>
    <table>
        <thead>
            <tr>
                <th>Feedback ID</th>
                <th>Order ID</th>
                <th>Customer Name</th>
                <th>Feedback</th>
                <th>Date</th>
            </tr>
        </thead>
        <tbody>
            <?php while ($feedback = $result->fetch_assoc()): ?>
                <tr>
                    <td><?= htmlspecialchars($feedback['FeedbackID']); ?></td>
                    <td><?= htmlspecialchars($feedback['OrderID']); ?></td>
                    <td><?= htmlspecialchars($feedback['CustomerName']); ?></td>
                    <td><?= htmlspecialchars($feedback['Feedback']); ?></td>
                    <td><?= htmlspecialchars($feedback['Date']); ?></td>
                </tr>
            <?php endwhile; ?>
        </tbody>
    </table>
</div>

<?php include('includes/footer.php'); ?>