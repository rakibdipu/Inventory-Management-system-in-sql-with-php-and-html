<?php
session_start();
include('includes/db.php');

// Check if the user is logged in as a customer
if (!isset($_SESSION['role']) || $_SESSION['role'] !== 'customer') {
    header('Location: index.php'); // Redirect if not logged in
    exit;
}

// Get customer name from session
$customer_name = isset($_SESSION['customer_name']) ? $_SESSION['customer_name'] : 'Guest';

// Fetch available products from the database
$query = "SELECT ProductID, ProductName, Price, AvailableQuantity FROM Products";
$result = $conn->query($query);

// Check for database query errors
if (!$result) {
    die("Database query failed: " . $conn->error);
}

include('includes/header.php');
?>

<div class="customer-dashboard">
    <h1>Welcome, <?= htmlspecialchars($customer_name); ?></h1>
    <h2>Available Products</h2>

    <table>
        <thead>
            <tr>
                <th>Product ID</th>
                <th>Product Name</th>
                <th>Price</th>
                <th>Stock</th>
                <th>Actions</th>
            </tr>
        </thead>
        <tbody>
            <?php while ($product = $result->fetch_assoc()): ?>
                <tr>
                    <td><?= htmlspecialchars($product['ProductID']); ?></td>
                    <td><?= htmlspecialchars($product['ProductName']); ?></td>
                    <td>$<?= htmlspecialchars($product['Price']); ?></td>
                    <td><?= htmlspecialchars($product['AvailableQuantity']); ?></td>
                    <td>
                        <?php if ($product['AvailableQuantity'] > 0): ?>
                            <!-- Buy Button -->
                            <form method="POST" action="buy_product.php" style="display:inline;">
                                <input type="hidden" name="product_id" value="<?= htmlspecialchars($product['ProductID']); ?>">
                                <button type="submit">Buy</button>
                            </form>
                        <?php else: ?>
                            <span>Out of Stock</span>
                        <?php endif; ?>
                    </td>
                </tr>
            <?php endwhile; ?>
        </tbody>
    </table>
</div>

<?php include('includes/footer.php'); ?>
