<?php
// place_order.php
session_start(); // Start the session
include('includes/db.php'); // Include the database connection

// Check if the user is logged in as a customer
if (!isset($_SESSION['role']) || $_SESSION['role'] !== 'customer') {
    header('Location: index.php'); // Redirect to login page if not a customer
    exit;
}

// Check if the product ID is provided
if (isset($_GET['product_id'])) {
    $product_id = $_GET['product_id'];

    // Fetch product details from the database
    $query = "SELECT * FROM Products WHERE ProductID = ?";
    $stmt = $conn->prepare($query);
    $stmt->bind_param("i", $product_id);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result->num_rows > 0) {
        $product = $result->fetch_assoc();
    } else {
        echo "Product not found.";
        exit;
    }
} else {
    echo "No product ID provided.";
    exit;
}

// Handle order placement
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $customer_id = $_SESSION['customer_id'];
    $quantity = $_POST['quantity'];

    // Check product availability
    if ($product['AvailableQuantity'] >= $quantity) {
        // Calculate total amount
        $total_amount = $product['Price'] * $quantity;

        // Insert order into Orders table
        $order_query = "INSERT INTO Orders (CustomerID, TotalAmount) VALUES (?, ?)";
        $order_stmt = $conn->prepare($order_query);
        $order_stmt->bind_param("id", $customer_id, $total_amount);
        $order_stmt->execute();

        // Get the last inserted order ID
        $order_id = $conn->insert_id;

        // Insert order details into OrderDetails table
        $order_detail_query = "INSERT INTO OrderDetails (OrderID, ProductID, Quantity, Price) VALUES (?, ?, ?, ?)";
        $order_detail_stmt = $conn->prepare($order_detail_query);
        $order_detail_stmt->bind_param("iiid", $order_id, $product_id, $quantity, $product['Price']);
        $order_detail_stmt->execute();

        // Update product quantity
        $new_quantity = $product['AvailableQuantity'] - $quantity;
        $update_product_query = "UPDATE Products SET AvailableQuantity = ? WHERE ProductID = ?";
        $update_product_stmt = $conn->prepare($update_product_query);
        $update_product_stmt->bind_param("ii", $new_quantity, $product_id);
        $update_product_stmt->execute();

        echo "Order placed successfully!";
        header('Location: product_listing.php'); // Redirect to product listing after successful order
        exit;
    } else {
        echo "Insufficient stock available.";
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Place Order - Amazon Bangladesh</title>
    <link rel="stylesheet" href="css/style.css"> <!-- Link to your CSS file -->
</head>
<body>
    <div class="order-container">
        <h2>Order Product: <?php echo htmlspecialchars($product['ProductName']); ?></h2>
        <form method="POST" action="">
            <div>
                <label for="quantity">Quantity:</label>
                <input type="number" id="quantity" name="quantity" min="1" max="<?php echo $product['AvailableQuantity']; ?>" required>
            </div>
            <button type="submit">Place Order</button>
        </form>
    </div>
</body>
</html>