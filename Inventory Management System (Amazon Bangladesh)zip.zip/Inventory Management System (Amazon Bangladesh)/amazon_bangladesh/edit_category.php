<?php
session_start();
include('includes/db.php'); // Include the database connection

// Check if the user is an admin
if (!isset($_SESSION['role']) || $_SESSION['role'] !== 'admin') {
    header('Location: index.php');
    exit;
}

// Check if category ID is provided
if (isset($_GET['id'])) {
    $categoryID = $_GET['id'];

    // Fetch category details
    $query = "SELECT * FROM Categories WHERE CategoryID = ?";
    $stmt = $conn->prepare($query);
    $stmt->bind_param("i", $categoryID);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result->num_rows > 0) {
        $category = $result->fetch_assoc();
    } else {
        echo "Category not found.";
        exit;
    }
} else {
    header('Location: view_categories.php');
    exit;
}

// Handle form submission
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $categoryName = $_POST['CategoryName'];
    $description = $_POST['Description'];

    $updateQuery = "UPDATE Categories SET CategoryName = ?, Description = ? WHERE CategoryID = ?";
    $stmt = $conn->prepare($updateQuery);
    $stmt->bind_param("ssi", $categoryName, $description, $categoryID);

    if ($stmt->execute()) {
        header('Location: view_categories.php?message=Category updated successfully');
        exit;
    } else {
        echo "Error updating category: " . $conn->error;
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Edit Category</title>
    <link rel="stylesheet" href="css/style.css">
</head>
<body>
    <h1>Edit Category</h1>
    <form method="POST">
        <label>Category Name:</label>
        <input type="text" name="CategoryName" value="<?= htmlspecialchars($category['CategoryName']); ?>" required><br>
        <label>Description:</label>
        <textarea name="Description" required><?= htmlspecialchars($category['Description']); ?></textarea><br>
        <button type="submit">Save Changes</button>
    </form>
</body>
</html>
