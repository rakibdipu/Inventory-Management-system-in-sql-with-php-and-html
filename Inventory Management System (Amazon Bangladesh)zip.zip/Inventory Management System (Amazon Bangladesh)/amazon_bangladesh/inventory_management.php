<?php
session_start();
include('includes/db.php');

// Check admin login
if (!isset($_SESSION['role']) || $_SESSION['role'] !== 'admin') {
    header('Location: index.php'); // Redirect if not admin
    exit;
}

// Fetch product inventory
$query = "SELECT p.ProductID, p.Name, p.Stock, w.Name AS WarehouseName 
          FROM products p 
          JOIN warehouses w ON p.WarehouseID = w.WarehouseID";
$result = $conn->query($query);

// Check for errors in the query
if (!$result) {
    die("Database query failed: " . $conn->error);
}

include('includes/header.php');
?>

<div class="inventory-management">
    <h1>Inventory Management</h1>
    <table>
        <thead>
            <tr>
                <th>Product ID</th>
                <th>Name</th>
                <th>Stock</th>
                <th>Warehouse</th>
                <th>Actions</th>
            </tr>
        </thead>
        <tbody>
            <?php while ($product = $result->fetch_assoc()): ?>
                <tr>
                    <td><?= htmlspecialchars($product['ProductID']); ?></td>
                    <td><?= htmlspecialchars($product['Name']); ?></td>
                    <td><?= htmlspecialchars($product['Stock']); ?></td>
                    <td><?= htmlspecialchars($product['WarehouseName']); ?></td>
                    <td>
                        <a href="edit_inventory.php?id=<?= htmlspecialchars($product['ProductID']); ?>">Edit</a>
                    </td>
                </tr>
            <?php endwhile; ?>
        </tbody>
    </table>
    <a href="add_inventory.php">Add New Product</a>
</div>

<?php include('includes/footer.php'); ?>