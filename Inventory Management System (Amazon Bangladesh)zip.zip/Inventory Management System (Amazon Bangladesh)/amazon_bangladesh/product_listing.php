<?php
session_start(); // Start the session
include('includes/db.php'); // Include the database connection

// Check if the user is logged in as a customer
if (!isset($_SESSION['role']) || $_SESSION['role'] !== 'customer') {
    header('Location: index.php'); // Redirect to login page if not a customer
    exit;
}

// Fetch products from the database
$query = "SELECT * FROM Products";
$result = $conn->query($query);

// Check for query execution errors
if (!$result) {
    die("Query failed: " . $conn->error);
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Product Listing - Amazon Bangladesh</title>
    <link rel="stylesheet" href="css/style.css"> <!-- Link to your CSS file -->
</head>
<body>
    <header>
        <h1>Available Products</h1>
        <nav>
            <ul>
                <li><a href="customer_dashboard.php">Dashboard</a></li>
                <li><a href="logout.php">Logout</a></li>
            </ul>
        </nav>
    </header>

    <main>
        <div class="product-listing-container">
            <?php if ($result->num_rows > 0): ?>
                <div class="product-cards">
                    <?php while ($row = $result->fetch_assoc()): ?>
                        <div class="product-card">
                            <img src="<?php echo htmlspecialchars($row['ImageURL']); ?>" alt="<?php echo htmlspecialchars($row['ProductName']); ?>">
                            <h3><?php echo htmlspecialchars($row['ProductName']); ?></h3>
                            <p>Description: <?php echo htmlspecialchars($row['Description']); ?></p>
                            <p>Price: $<?php echo htmlspecialchars($row['Price']); ?></p>
                            <p>Available: <?php echo htmlspecialchars($row['AvailableQuantity']); ?></p>
                            <form action="place_order.php" method="GET">
                                <input type="hidden" name="product_id" value="<?php echo htmlspecialchars($row['ProductID']); ?>">
                                <button type="submit">Add to Cart</button>
                            </form>
                        </div>
                    <?php endwhile; ?>
                </div>
            <?php else: ?>
                <p>No products available at the moment.</p>
            <?php endif; ?>
        </div>
    </main>

    <footer>
        <p>&copy; <?php echo date("Y"); ?> Amazon Bangladesh. All rights reserved.</p>
    </footer>
</body>
</html>