<?php
session_start();
include('includes/db.php');

// Check customer login
if (!isset($_SESSION['role']) || $_SESSION['role'] !== 'customer') {
    header('Location: index.php'); // Redirect if not customer
    exit;
}

// Fetch order summary for the logged-in customer
$query = "SELECT o.OrderID, o.OrderDate, o.Status, SUM(oi.Quantity) AS TotalItems, SUM(oi.Quantity * p.Price) AS TotalAmount 
          FROM orders o 
          JOIN order_items oi ON o.OrderID = oi.OrderID 
          JOIN products p ON oi.ProductID = p.ProductID 
          WHERE o.CustomerID = ? 
          GROUP BY o.OrderID";
$stmt = $conn->prepare($query);
$stmt->bind_param("i", $_SESSION['customer_id']);
$stmt->execute();
$result = $stmt->get_result();

include('includes/header.php');
?>

<div class="order-summary">
    <h1>Your Order Summary</h1>
    <table>
        <thead>
            <tr>
                <th>Order ID</th>
                <th>Order Date</th>
                <th>Status</th>
                <th>Total Items</th>
                <th>Total Amount</th>
            </tr>
        </thead>
        <tbody>
            <?php while ($order = $result->fetch_assoc()): ?>
                <tr>
                    <td><?= htmlspecialchars($order['OrderID']); ?></td>
                    <td><?= htmlspecialchars($order['OrderDate']); ?></td>
                    <td><?= htmlspecialchars($order['Status']); ?></td>
                    <td><?= htmlspecialchars($order['TotalItems']); ?></td>
                    <td><?= htmlspecialchars($order['TotalAmount']); ?></td>
                </tr>
            <?php endwhile; ?>
        </tbody>
    </table>
</div>

<?php include('includes/footer.php'); ?>
