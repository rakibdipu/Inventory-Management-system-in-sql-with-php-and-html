<?php
session_start();
include('includes/db.php');

// Check if the user is logged in as an admin
if (!isset($_SESSION['role']) || $_SESSION['role'] !== 'admin') {
    header('Location: index.php'); // Redirect to login page if not an admin
    exit;
}

// Handle pagination variables
$limit = 10; // Number of records per page
$page = isset($_GET['page']) ? (int)$_GET['page'] : 1;
$offset = ($page - 1) * $limit;

// Handle search functionality
$search = isset($_GET['search']) ? trim($_GET['search']) : '';
$searchQuery = $search ? "WHERE SupplierName LIKE ? OR ContactName LIKE ?" : '';

// Fetch suppliers from the database
$query = "SELECT SupplierID, SupplierName, ContactName, Address, City, PostalCode, Country FROM Suppliers $searchQuery LIMIT ? OFFSET ?";
$stmt = $conn->prepare($query);

if ($search) {
    $searchParam = "%$search%";
    $stmt->bind_param('ssii', $searchParam, $searchParam, $limit, $offset);
} else {
    $stmt->bind_param('ii', $limit, $offset);
}

$stmt->execute();
$result = $stmt->get_result();

// Get the total number of records for pagination
$totalQuery = "SELECT COUNT(*) AS total FROM Suppliers $searchQuery";
$totalStmt = $conn->prepare($totalQuery);

if ($search) {
    $totalStmt->bind_param('ss', $searchParam, $searchParam);
}

$totalStmt->execute();
$totalResult = $totalStmt->get_result();
$totalRecords = $totalResult->fetch_assoc()['total'];
$totalPages = ceil($totalRecords / $limit);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Manage Suppliers - Amazon Bangladesh</title>
    <link rel="stylesheet" href="css/style.css">
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f4f4f4;
            margin: 0;
            padding: 20px;
        }
        header {
            background: #007BFF;
            color: white;
            padding: 10px 20px;
            text-align: center;
        }
        nav ul {
            list-style: none;
            padding: 0;
        }
        nav ul li {
            display: inline;
            margin-right: 15px;
        }
        nav ul li a {
            color: white;
            text-decoration: none;
        }
        main {
            margin-top: 20px;
            padding: 20px;
            background: white;
            border-radius: 5px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
        }
        table {
            width: 100%;
            border-collapse: collapse;
        }
        table, th, td {
            border: 1px solid #ddd;
        }
        th, td {
            padding: 8px;
            text-align: left;
        }
        th {
            background-color: #007BFF;
            color: white;
        }
        footer {
            text-align: center;
            margin-top: 20px;
            font-size: 0.9em;
        }
        .pagination {
            margin-top: 10px;
            text-align: center;
        }
        .pagination a {
            margin: 0 5px;
            padding: 5px 10px;
            background: #007BFF;
            color: white;
            text-decoration: none;
            border-radius: 3px;
        }
        .pagination a.active {
            background: #0056b3;
        }
        .search-bar {
            margin-bottom: 15px;
        }
        .search-bar input {
            padding: 5px;
            width: 200px;
        }
        .add-supplier-btn {
            margin-bottom: 20px;
            display: inline-block;
            padding: 10px 15px;
            background-color: #28a745;
            color: white;
            text-decoration: none;
            border-radius: 5px;
        }
        .add-supplier-btn:hover {
            background-color: #218838;
        }
    </style>
</head>
<body>
    <header>
        <h1>Manage Suppliers</h1>
        <nav>
            <ul>
                <li><a href="admin_dashboard.php">Dashboard</a></li>
                <li><a href="view_customers.php">Manage Customers</a></li>
                <li><a href="view_orders.php">View Orders</a></li>
                <li><a href="view_warehouse.php">Manage Warehouse</a></li>
                <li><a href="view_categories.php">Manage Categories</a></li>
                <li><a href="logout.php">Logout</a></li>
            </ul>
        </nav>
    </header>

    <main>
        <div class="search-bar">
            <form method="GET" action="">
                <input type="text" name="search" placeholder="Search by Supplier Name or Contact Name" value="<?php echo htmlspecialchars($search); ?>">
                <button type="submit">Search</button>
            </form>
        </div>

        <div class="supplier-listing-container">
            <a href="add_supplier.php" class="add-supplier-btn">Add New Supplier</a>
            <?php if ($result->num_rows > 0): ?>
                <table>
                    <thead>
                        <tr>
                            <th>Supplier ID</th>
                            <th>Supplier Name</th>
                            <th>Contact Name</th>
                            <th>Address</th>
                            <th>City</th>
                            <th>Postal Code</th>
                            <th>Country</th>
                            <th>Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php while ($row = $result->fetch_assoc()): ?>
                            <tr>
                                <td><?= htmlspecialchars($row['SupplierID']); ?></td>
                                <td><?= htmlspecialchars($row['SupplierName']); ?></td>
                                <td><?= htmlspecialchars($row['ContactName']); ?></td>
                                <td><?= htmlspecialchars($row['Address']); ?></td>
                                <td><?= htmlspecialchars($row['City']); ?></td>
                                <td><?= htmlspecialchars($row['PostalCode']); ?></td>
                                <td><?= htmlspecialchars($row['Country']); ?></td>
                                <td>
                                    <a href="edit_supplier.php?id=<?= $row['SupplierID']; ?>">Edit</a> | 
                                    <a href="delete_supplier.php?id=<?= $row['SupplierID']; ?>" onclick="return confirm('Are you sure you want to delete this supplier?');">Delete</a>
                                </td>
                            </tr>
                        <?php endwhile; ?>
                    </tbody>
                </table>
            <?php else: ?>
                <p>No suppliers found.</p>
            <?php endif; ?>
        </div>

        <div class="pagination">
            <?php for ($i = 1; $i <= $totalPages; $i++): ?>
                <a href="?page=<?= $i; ?>&search=<?= urlencode($search); ?>" class="<?= $i === $page ? 'active' : ''; ?>">
                    <?= $i; ?>
                </a>
            <?php endfor; ?>
        </div>
    </main>

    <footer>
        <p>&copy; <?= date("Y"); ?> Amazon Bangladesh. All rights reserved.</p>
    </footer>
</body>
</html>
