<?php
session_start();
include('includes/db.php');

// Check customer login
if (!isset($_SESSION['role']) || $_SESSION['role'] !== 'customer') {
    header('Location: index.php'); // Redirect if not customer
    exit;
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $order_id = $_POST['order_id'];
    $feedback = $_POST['feedback'];

    // Insert feedback into the database
    $query = "INSERT INTO feedback (OrderID, CustomerID, Feedback, Date) VALUES (?, ?, ?, NOW())";
    $stmt = $conn->prepare($query);
    $stmt->bind_param("iis", $order_id, $_SESSION['customer_id'], $feedback);
    $stmt->execute();

    if ($stmt->affected_rows > 0) {
        echo "Feedback submitted successfully!";
    } else {
        echo "Error submitting feedback: " . $conn->error;
    }
}

$orders = $conn->query("SELECT OrderID, OrderDate FROM orders WHERE CustomerID = " . $_SESSION['customer_id']);

include('includes/header.php');
?>

<div class="customer-feedback">
    <h1>Submit Feedback</h1>
    <form method="POST" action="">
        <label for="order_id">Select Order:</label>
        <select name="order_id" required>
            <?php while ($order = $orders->fetch_assoc()): ?>
                <option value="<?= htmlspecialchars($order['OrderID']); ?>"><?= htmlspecialchars($order['OrderDate']); ?></option>
            <?php endwhile; ?>
        </select>
        <label for="feedback">Feedback:</label>
        <textarea name="feedback" required></textarea>
        <button type="submit">Submit Feedback</button>
    </form>
    <a href="customer_dashboard.php">Back to Dashboard</a>
</div>

<?php include('includes/footer.php'); ?>