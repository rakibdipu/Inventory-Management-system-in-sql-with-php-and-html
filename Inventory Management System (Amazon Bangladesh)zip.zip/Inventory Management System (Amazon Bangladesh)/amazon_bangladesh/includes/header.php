<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Amazon Bangladesh</title>
    <link rel="stylesheet" href="css/style.css"> <!-- Link to the stylesheet -->
</head>
<body>
    <header>
        <h1>Welcome to Amazon Bangladesh</h1>
        <nav>
            <ul>
                <li><a href="index.php">Home</a></li>
                <li><a href="admin_dashboard.php">Admin Dashboard</a></li>
                <li><a href="customer_dashboard.php">Customer Dashboard</a></li>
                <li><a href="process_login.php?logout=true">Logout</a></li>
            </ul>
        </nav>
    </header>