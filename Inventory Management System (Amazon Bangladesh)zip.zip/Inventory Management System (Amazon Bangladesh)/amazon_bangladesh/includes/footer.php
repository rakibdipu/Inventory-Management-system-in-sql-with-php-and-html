<footer>
    <p>&copy; <?php echo date("Y"); ?> Amazon Bangladesh. All rights reserved.</p>
</footer>
</body>
</html>