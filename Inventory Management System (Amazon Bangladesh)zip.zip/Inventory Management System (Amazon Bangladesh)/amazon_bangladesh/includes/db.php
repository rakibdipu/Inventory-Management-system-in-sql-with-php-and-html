<?php
$servername = "localhost"; // Database server name
$username = "root"; // Default XAMPP username
$password = ""; // Default XAMPP password (leave empty if you haven't set one)
$dbname = "amazon_bangladesh"; // Your database name

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}
?>