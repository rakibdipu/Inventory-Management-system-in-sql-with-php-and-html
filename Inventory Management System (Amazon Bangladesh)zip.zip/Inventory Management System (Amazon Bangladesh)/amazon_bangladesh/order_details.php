<?php
session_start();
include('includes/db.php');

// Check customer login
if (!isset($_SESSION['role']) || $_SESSION['role'] !== 'customer') {
    header('Location: index.php'); // Redirect if not customer
    exit;
}

// Fetch orders for the logged-in customer
$query = "SELECT o.OrderID, o.OrderDate, o.Status, p.Name, p.Price 
          FROM orders o 
          JOIN products p ON o.ProductID = p.ProductID 
          WHERE o.CustomerID = ?";
$stmt = $conn->prepare($query);
$stmt->bind_param("i", $_SESSION['customer_id']);
$stmt->execute();
$result = $stmt->get_result();

include('includes/header.php');
?>

<div class="order-details">
    <h1>Your Orders</h1>
    <table>
        <thead>
            <tr>
                <th>Order ID</th>
                <th>Product Name</th>
                <th>Order Date</th>
                <th>Status</th>
                <th>Price</th>
            </tr>
        </thead>
        <tbody>
            <?php while ($order = $result->fetch_assoc()): ?>
                <tr>
                    <td><?= htmlspecialchars($order['OrderID']); ?></td>
                    <td><?= htmlspecialchars($order['Name']); ?></td>
                    <td><?= htmlspecialchars($order['OrderDate']); ?></td>
                    <td><?= htmlspecialchars($order['Status']); ?></td>
                    <td><?= htmlspecialchars($order['Price']); ?></td>
                </tr>
            <?php endwhile; ?>
        </tbody>
    </table>
</div>

<?php include('includes/footer.php'); ?>