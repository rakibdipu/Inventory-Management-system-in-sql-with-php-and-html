<?php
session_start();
include('includes/db.php');

// Check admin login
if (!isset($_SESSION['role']) || $_SESSION['role'] !== 'admin') {
    header('Location: index.php'); // Redirect if not admin
    exit;
}

// Fetch warehouse details
$query = "SELECT * FROM warehouses";
$result = $conn->query($query);

// Check for errors in the query
if (!$result) {
    die("Database query failed: " . $conn->error);
}

include('includes/header.php');
?>

<div class="warehouse-management">
    <h1>Warehouse Management</h1>
    <table>
        <thead>
            <tr>
                <th>Warehouse ID</th>
                <th>Name</th>
                <th>Location</th>
                <th>Actions</th>
            </tr>
        </thead>
        <tbody>
            <?php while ($warehouse = $result->fetch_assoc()): ?>
                <tr>
                    <td><?= htmlspecialchars($warehouse['WarehouseID']); ?></td>
                    <td><?= htmlspecialchars($warehouse['Name']); ?></td>
                    <td><?= htmlspecialchars($warehouse['Location']); ?></td>
                    <td>
                        <a href="edit_warehouse.php?id=<?= htmlspecialchars($warehouse['WarehouseID']); ?>">Edit</a>
                        <a href="delete_warehouse.php?id=<?= htmlspecialchars($warehouse['WarehouseID']); ?>">Delete</a>
                    </td>
                </tr>
            <?php endwhile; ?>
        </tbody>
    </table>
    <a href="add_warehouse.php">Add New Warehouse</a>
</div>

<?php include('includes/footer.php'); ?>