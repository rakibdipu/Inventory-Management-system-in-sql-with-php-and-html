<?php
session_start();
include('includes/db.php'); // Adjust the path if in a subdirectory

// Check admin authentication
if (!isset($_SESSION['role']) || $_SESSION['role'] !== 'admin') {
    header('Location: ../index.php');
    exit;
}

// Get supplier details
if (isset($_GET['id'])) {
    $supplierID = $_GET['id'];

    $query = "SELECT * FROM Suppliers WHERE SupplierID = ?";
    $stmt = $conn->prepare($query);
    $stmt->bind_param("i", $supplierID);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result->num_rows === 0) {
        echo "Supplier not found.";
        exit;
    }

    $supplier = $result->fetch_assoc();
} else {
    header('Location: amazon_bangladesh/view_suppliers.php');
    exit;
}

// Handle form submission
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $supplierName = $_POST['SupplierName'];
    $contactName = $_POST['ContactName'];
    $address = $_POST['Address'];
    $city = $_POST['City'];
    $postalCode = $_POST['PostalCode'];
    $country = $_POST['Country'];

    $updateQuery = "UPDATE Suppliers SET SupplierName = ?, ContactName = ?, Address = ?, City = ?, PostalCode = ?, Country = ? WHERE SupplierID = ?";
    $stmt = $conn->prepare($updateQuery);
    $stmt->bind_param("ssssssi", $supplierName, $contactName, $address, $city, $postalCode, $country, $supplierID);

    if ($stmt->execute()) {
        header('Location: amazon_bangladesh/view_suppliers.php');
        exit;
    } else {
        echo "Error updating supplier: " . $conn->error;
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Edit Supplier</title>
</head>
<body>
    <h1>Edit Supplier</h1>
    <form method="POST">
        <label>Supplier Name:</label>
        <input type="text" name="SupplierName" value="<?= htmlspecialchars($supplier['SupplierName']); ?>" required><br>
        <label>Contact Name:</label>
        <input type="text" name="ContactName" value="<?= htmlspecialchars($supplier['ContactName']); ?>" required><br>
        <label>Address:</label>
        <input type="text" name="Address" value="<?= htmlspecialchars($supplier['Address']); ?>" required><br>
        <label>City:</label>
        <input type="text" name="City" value="<?= htmlspecialchars($supplier['City']); ?>" required><br>
        <label>Postal Code:</label>
        <input type="text" name="PostalCode" value="<?= htmlspecialchars($supplier['PostalCode']); ?>" required><br>
        <label>Country:</label>
        <input type="text" name="Country" value="<?= htmlspecialchars($supplier['Country']); ?>" required><br>
        <button type="submit">Save Changes</button>
    </form>
</body>
</html>
