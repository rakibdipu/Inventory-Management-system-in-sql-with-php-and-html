<?php
session_start();
include('includes/db.php');

// Check admin login
if (!isset($_SESSION['role']) || $_SESSION['role'] !== 'admin') {
    header('Location: index.php'); // Redirect if not admin
    exit;
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $name = $_POST['name'];
    $location = $_POST['location'];

    // Insert new warehouse into the database
    $query = "INSERT INTO warehouses (Name, Location) VALUES (?, ?)";
    $stmt = $conn->prepare($query);
    $stmt->bind_param("ss", $name, $location);
    $stmt->execute();

    if ($stmt->affected_rows > 0) {
        header('Location: warehouse_management.php'); // Redirect to warehouse management
        exit;
    } else {
        echo "Error adding warehouse: " . $conn->error;
    }
}

include('includes/header.php');
?>

<div class="add-warehouse">
    <h1>Add New Warehouse</h1>
    <form method="POST" action="">
        <label for="name">Warehouse Name:</label>
        <input type="text" name="name" required>
        <label for="location">Location:</label>
        <input type="text" name="location" required>
        <button type="submit">Add Warehouse</button>
    </form>
    <a href="warehouse_management.php">Back to Warehouse Management</a>
</div>

<?php include('includes/footer.php'); ?>