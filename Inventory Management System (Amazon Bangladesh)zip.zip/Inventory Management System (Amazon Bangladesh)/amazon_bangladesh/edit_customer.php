<?php
session_start();
include('includes/db.php'); // Include the database connection

// Check if the user is an admin
if (!isset($_SESSION['role']) || $_SESSION['role'] !== 'admin') {
    header('Location: index.php');
    exit;
}

// Check if customer ID is provided
if (isset($_GET['id'])) {
    $customerID = $_GET['id'];

    // Fetch customer details
    $query = "SELECT * FROM Customers WHERE CustomerID = ?";
    $stmt = $conn->prepare($query);
    $stmt->bind_param("i", $customerID);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result->num_rows > 0) {
        $customer = $result->fetch_assoc();
    } else {
        echo "Customer not found.";
        exit;
    }
} else {
    header('Location: view_customers.php');
    exit;
}

// Handle form submission
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $customerName = $_POST['CustomerName'];
    $email = $_POST['Email'];
    $contactName = $_POST['ContactName'];
    $address = $_POST['Address'];
    $city = $_POST['City'];
    $postalCode = $_POST['PostalCode'];
    $country = $_POST['Country'];

    $updateQuery = "UPDATE Customers SET CustomerName = ?, Email = ?, ContactName = ?, Address = ?, City = ?, PostalCode = ?, Country = ? WHERE CustomerID = ?";
    $stmt = $conn->prepare($updateQuery);
    $stmt->bind_param("sssssssi", $customerName, $email, $contactName, $address, $city, $postalCode, $country, $customerID);

    if ($stmt->execute()) {
        header('Location: view_customers.php?message=Customer updated successfully');
        exit;
    } else {
        echo "Error updating customer: " . $conn->error;
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Edit Customer</title>
</head>
<body>
    <h1>Edit Customer</h1>
    <form method="POST">
        <label>Customer Name:</label>
        <input type="text" name="CustomerName" value="<?= htmlspecialchars($customer['CustomerName']); ?>" required><br>
        <label>Email:</label>
        <input type="email" name="Email" value="<?= htmlspecialchars($customer['Email']); ?>" required><br>
        <label>Contact Name:</label>
        <input type="text" name="ContactName" value="<?= htmlspecialchars($customer['ContactName']); ?>" required><br>
        <label>Address:</label>
        <input type="text" name="Address" value="<?= htmlspecialchars($customer['Address']); ?>" required><br>
        <label>City:</label>
        <input type="text" name="City" value="<?= htmlspecialchars($customer['City']); ?>" required><br>
        <label>Postal Code:</label>
        <input type="text" name="PostalCode" value="<?= htmlspecialchars($customer['PostalCode']); ?>" required><br>
        <label>Country:</label>
        <input type="text" name="Country" value="<?= htmlspecialchars($customer['Country']); ?>" required><br>
        <button type="submit">Save Changes</button>
    </form>
</body>
</html>
