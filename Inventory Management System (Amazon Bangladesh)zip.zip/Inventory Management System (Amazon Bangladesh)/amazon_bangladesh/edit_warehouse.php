<?php
session_start();
include('includes/db.php');

// Check admin login
if (!isset($_SESSION['role']) || $_SESSION['role'] !== 'admin') {
    header('Location: index.php'); // Redirect if not admin
    exit;
}

// Check if the warehouse ID is provided
if (!isset($_GET['id'])) {
    header('Location: warehouse_management.php'); // Redirect if no warehouse ID is provided
    exit;
}

$warehouse_id = $_GET['id'];

// Fetch warehouse details
$query = "SELECT * FROM warehouses WHERE WarehouseID = ?";
$stmt = $conn->prepare($query);
$stmt->bind_param("i", $warehouse_id);
$stmt->execute();
$result = $stmt->get_result();

if ($result->num_rows === 0) {
    header('Location: warehouse_management.php'); // Redirect if warehouse not found
    exit;
}

$warehouse = $result->fetch_assoc();

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $name = $_POST['name'];
    $location = $_POST['location'];

    // Update warehouse details
    $update_query = "UPDATE warehouses SET Name = ?, Location = ? WHERE WarehouseID = ?";
    $stmt = $conn->prepare($update_query);
    $stmt->bind_param("ssi", $name, $location, $warehouse_id);
    $stmt->execute();

    if ($stmt->affected_rows > 0) {
        header('Location: warehouse_management.php'); // Redirect to warehouse management
        exit;
    } else {
        echo "Error updating warehouse: " . $conn->error;
    }
}

include('includes/header.php');
?>

<div class="edit-warehouse">
    <h1>Edit Warehouse</h1>
    <form method="POST" action="">
        <label for="name">Warehouse Name:</label>
        <input type="text" name="name" value="<?= htmlspecialchars($warehouse['Name']); ?>" required>
        <label for="location">Location:</label>
        <input type="text" name="location" value="<?= htmlspecialchars($warehouse['Location']); ?>" required>
        <button type="submit">Update Warehouse</button>
    </form>
    <a href="warehouse_management.php">Back to Warehouse Management</a>
</div>

<?php include('includes/footer.php'); ?>