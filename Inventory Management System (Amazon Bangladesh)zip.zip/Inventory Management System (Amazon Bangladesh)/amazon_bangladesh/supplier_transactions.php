<?php
session_start();
include('includes/db.php');

// Check admin login
if (!isset($_SESSION['role']) || $_SESSION['role'] !== 'admin') {
    header('Location: index.php'); // Redirect if not admin
    exit;
}

// Fetch supplier transaction history
$query = "SELECT t.TransactionID, t.SupplierID, t.Amount, t.Date, s.Name AS SupplierName 
          FROM transactions t 
          JOIN suppliers s ON t.SupplierID = s.SupplierID";
$result = $conn->query($query);

// Check for errors in the query
if (!$result) {
    die("Database query failed: " . $conn->error);
}

include('includes/header.php');
?>

<div class="supplier-transactions">
    <h1>Supplier Transaction History</h1>
    <table>
        <thead>
            <tr>
                <th>Transaction ID</th>
                <th>Supplier Name</th>
                <th>Amount</th>
                <th>Date</th>
            </tr>
        </thead>
        <tbody>
            <?php while ($transaction = $result->fetch_assoc()): ?>
                <tr>
                    <td><?= htmlspecialchars($transaction['TransactionID']); ?></td>
                    <td><?= htmlspecialchars($transaction['SupplierName']); ?></td>
                    <td><?= htmlspecialchars($transaction['Amount']); ?></td>
                    <td><?= htmlspecialchars($transaction['Date']); ?></td>
                </tr>
            <?php endwhile; ?>
        </tbody>
    </table>
</div>

<?php include('includes/footer.php'); ?>