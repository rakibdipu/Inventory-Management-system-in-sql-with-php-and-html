<?php
session_start();
include('includes/db.php');

// Check admin login
if (!isset($_SESSION['role']) || $_SESSION['role'] !== 'admin') {
    header('Location: index.php'); // Redirect if not admin
    exit;
}

// Fetch data
$customers = $conn->query("SELECT * FROM customers");
$orders = $conn->query("SELECT * FROM orders");
$suppliers = $conn->query("SELECT * FROM suppliers");
$categories = $conn->query("SELECT * FROM categories");
$warehouses = $conn->query("SELECT * FROM warehouses");
$transactions = $conn->query("SELECT * FROM transactions");
// Check for errors in the queries
if (!$customers || !$orders || !$suppliers || !$categories || !$warehouses || !$transactions ) {
    die("Database query failed: " . $conn->error);
}

include('includes/header.php');
?>

<div class="admin-dashboard">
    <h1>Admin Dashboard</h1>
    <a href="process_login.php?logout=true" class="logout-button">Logout</a>

    <h2>Manage Customers</h2>
    <table>
        <thead>
            <tr>
                <th>Customer ID</th>
                <th>Name</th>
                <th>Email</th>
                <th>Actions</th>
            </tr>
        </thead>
        <tbody>
            <?php while ($customer = $customers->fetch_assoc()): ?>
                <tr>
                    <td><?= htmlspecialchars($customer['CustomerID']); ?></td>
                    <td><?= htmlspecialchars($customer['CustomerName']); ?></td>
                    <td><?= htmlspecialchars($customer['Email']); ?></td>
                    <td>
                        <a href="edit_customer.php?id=<?= htmlspecialchars($customer['CustomerID']); ?>">Edit</a>
                        <a href="delete_customer.php?id=<?= htmlspecialchars($customer['CustomerID']); ?>">Delete</a>
                    </td>
                </tr>
            <?php endwhile; ?>
        </tbody>
    </table>

    <h2>View Orders</h2>
    <table>
        <thead>
            <tr>
                <th>Order ID</th>
                <th>Customer ID</th>
                <th>Order Date</th>
                <th>Status</th>
            </tr>
        </thead>
        <tbody>
            <?php while ($order = $orders->fetch_assoc()): ?>
                <tr>
                    <td><?= htmlspecialchars($order['OrderID']); ?></td>
                    <td><?= htmlspecialchars($order['CustomerID']); ?></td>
                    <td><?= htmlspecialchars($order['OrderDate']); ?></td>
                    <td><?= htmlspecialchars($order['Status'] ?? 'Pending'); ?></td>
                </tr>
            <?php endwhile; ?>
        </tbody>
    </table>

    <h2>Manage Suppliers</h2>
    <table>
        <thead>
            <tr>
                <th>Supplier ID</th>
                <th>Name</th>
                <th>Contact</th>
                <th>Actions</th>
            </tr>
        </thead>
        <tbody>
            <?php while ($supplier = $suppliers->fetch_assoc()): ?>
                <tr>
                    <td><?= htmlspecialchars($supplier['SupplierID']); ?></td>
                    <td><?= htmlspecialchars($supplier['SupplierName']); ?></td>
                    <td><?= htmlspecialchars($supplier['ContactName']); ?></td>
                    <td>
                        <a href="edit_supplier.php?id=<?= htmlspecialchars($supplier['SupplierID']); ?>">Edit</a>
                        <a href="delete_supplier.php?id=<?= htmlspecialchars($supplier['SupplierID']); ?>">Delete</a>
                    </td>
                </tr>
            <?php endwhile; ?>
        </tbody>
    </table>

    <h2>Manage Categories</h2>
    <table>
        <thead>
            <tr>
                <th>Category ID</th>
                <th>Name</th>
                <th>Actions</th>
            </tr>
        </thead>
        <tbody>
            <?php while ($category = $categories->fetch_assoc()): ?>
                <tr>
                    <td><?= htmlspecialchars($category['CategoryID']); ?></td>
                    <td><?= htmlspecialchars($category['CategoryName']); ?></td>
                    <td>
                        <a href="edit_category.php?id=<?= htmlspecialchars($category['CategoryID']); ?>">Edit</a>
                        <a href="delete_category.php?id=<?= htmlspecialchars($category['CategoryID']); ?>">Delete</a>
                    </td>
                </tr>
            <?php endwhile; ?>
        </tbody>
    </table>

    <h2>Manage Warehouses</h2>
    <table>
        <thead>
            <tr>
                <th>Warehouse ID</th>
                <th>Warehouse Name</th>
                <th>Location</th>
                <th>Actions</th>
            </tr>
        </thead>
        <tbody>
            <?php while ($warehouse = $warehouses->fetch_assoc()): ?>
                <tr>
                    <td><?= htmlspecialchars($warehouse['WarehouseID']); ?></td>
                    <td><?= htmlspecialchars($warehouse['WarehouseName']); ?></td>
                    <td><?= htmlspecialchars($warehouse['Location']); ?></td>
                    <td>
                        <a href="edit_warehouse.php?id=<?= htmlspecialchars($warehouse['WarehouseID']); ?>">Edit</a>
                        <a href="delete_warehouse.php?id=<?= htmlspecialchars($warehouse['WarehouseID']); ?>">Delete</a>
                    </td>
                </tr>
            <?php endwhile; ?>
        </tbody>
    </table>

    <h2>View Transactions</h2>
    <table>
        <thead>
            <tr>
                <th>Transaction ID</th>
                <th>Product ID</th>
                <th>Warehouse ID</th>
                <th>Quantity</th>
                <th>Transaction Date</th>
            </tr>
        </thead>
        <tbody>
            <?php while ($transaction = $transactions->fetch_assoc()): ?>
                <tr>
                    <td><?= htmlspecialchars($transaction['TransactionID']); ?></td>
                    <td><?= htmlspecialchars($transaction['ProductID']); ?></td>
                    <td><?= htmlspecialchars($transaction['WarehouseID']); ?></td>
                    <td><?= htmlspecialchars($transaction['Quantity']); ?></td>
                    <td><?= htmlspecialchars($transaction['TransactionDate']); ?></td>
                </tr>
            <?php endwhile; ?>
        </tbody>
    </table>
</div>

<?php include('includes/footer.php'); ?>
