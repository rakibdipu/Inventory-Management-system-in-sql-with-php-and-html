<?php
session_start();
include('includes/db.php');

// Check if the supplier ID is provided
if (!isset($_GET['id'])) {
    header('Location: admin_dashboard.php'); // Redirect if no supplier ID is provided
    exit;
}

// Fetch supplier details based on the provided supplier ID
$supplier_id = $_GET['id'];
$query = "SELECT * FROM suppliers WHERE SupplierID = ?";
$stmt = $conn->prepare($query);
$stmt->bind_param("i", $supplier_id);
$stmt->execute();
$result = $stmt->get_result();

if ($result->num_rows === 0) {
    header('Location: admin_dashboard.php'); // Redirect if supplier not found
    exit;
}

$supplier = $result->fetch_assoc();

include('includes/header.php');
?>

<div class="supplier-details">
    <h1>Supplier Details</h1>
    <h2><?= htmlspecialchars($supplier['Name']); ?></h2>
    <p><strong>Contact:</strong> <?= htmlspecialchars($supplier['Contact']); ?></p>
    <p><strong>Email:</strong> <?= htmlspecialchars($supplier['Email']); ?></p>
    <p><strong>Address:</strong> <?= htmlspecialchars($supplier['Address']); ?></p>

    <a href="admin_dashboard.php">Back to Dashboard</a>
</div>

<?php include('includes/footer.php'); ?>