// Logout functionality
if (isset($_GET['logout'])) {
    session_destroy(); // Destroy the session
    header('Location: process_login.php'); // Redirect to login page
    exit;
}