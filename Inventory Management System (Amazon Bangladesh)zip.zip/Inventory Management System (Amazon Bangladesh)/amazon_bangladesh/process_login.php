<?php
session_start();
include('includes/db.php'); // Include the database connection

$error_message = ""; // Initialize error message
$success_message = ""; // Initialize success message

// Check if the form is submitted
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    // Admin login
    if (isset($_POST['admin_login'])) {
        $admin_email = $_POST['admin_email'];
        $admin_password = $_POST['admin_password'];

        // Corrected SQL query to check admin credentials
        $query = "SELECT * FROM Admins WHERE Email = ?";
        $stmt = $conn->prepare($query);
        $stmt->bind_param("s", $admin_email);
        $stmt->execute();
        $result = $stmt->get_result();

        if ($result->num_rows > 0) {
            $admin = $result->fetch_assoc();
            // Verify the password
            if (password_verify($admin_password, $admin['Password'])) {
                $_SESSION['role'] = 'admin';
                $_SESSION['admin_id'] = $admin['AdminID']; // Store admin ID
                $_SESSION['admin_email'] = $admin['Email']; // Store admin email
                header('Location: admin_dashboard.php'); // Redirect to admin dashboard
                exit;
            } else {
                $error_message = "Invalid admin email or password.";
            }
        } else {
            $error_message = "Invalid admin email or password.";
        }
    }

    // Customer login
    if (isset($_POST['customer_login'])) {
        $customer_email = $_POST['customer_email'];
        $customer_password = $_POST['customer_password'];

        // Prepare SQL to check customer credentials
        $query = "SELECT * FROM Customers WHERE Email = ?";
        $stmt = $conn->prepare($query);
        $stmt->bind_param("s", $customer_email);
        $stmt->execute();
        $result = $stmt->get_result();

        if ($result->num_rows > 0) {
            $customer = $result->fetch_assoc();
            // Verify the password
            if (password_verify($customer_password, $customer['Password'])) {
                $_SESSION['role'] = 'customer';
                $_SESSION['customer_id'] = $customer['CustomerID']; // Store customer ID
                $_SESSION['customer_name'] = $customer['Name']; // Store customer name
                header('Location: customer_dashboard.php'); // Redirect to customer dashboard
                exit;
            } else {
                $error_message = "Invalid customer email or password.";
            }
        } else {
            $error_message = "Invalid customer email or password.";
        }
    }

    // Customer registration
    if (isset($_POST['register'])) {
        $customer_name = $_POST['customer_name'];
        $contact_name = $_POST['contact_name'];
        $address = $_POST['address'];
        $city = $_POST['city'];
        $postal_code = $_POST['postal_code'];
        $country = $_POST['country'];
        $new_customer_email = $_POST['new_customer_email'];
        $new_customer_password = password_hash($_POST['new_customer_password'], PASSWORD_DEFAULT); // Hash the password

        // Insert new customer into the database
        $query = "INSERT INTO Customers (Name, ContactName, Address, City, PostalCode, Country, Email, Password) VALUES (?, ?, ?, ?, ?, ?, ?, ?)";
        $stmt = $conn->prepare($query);
        $stmt->bind_param("ssssssss", $customer_name, $contact_name, $address, $city, $postal_code, $country, $new_customer_email, $new_customer_password);
        if ($stmt->execute()) {
            $success_message = "Account created successfully! You can now log in.";
        } else {
            $error_message = "Error creating account. Please try again.";
        }
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login - Amazon Bangladesh</title>
    <link rel="stylesheet" href="css/style.css">
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f4f4f4;
            margin: 0;
            padding: 20px;
        }
        .login-container {
            max-width: 400px;
            margin: auto;
            background: white;
            padding: 20px;
            border-radius: 5px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
        }
        h2 {
            text-align: center;
        }
        .error-message {
            color: red;
            text-align: center;
        }
        .success-message {
            color: green;
            text-align: center;
        }
        .form-group {
            margin-bottom: 15px;
        }
        .form-group label {
            display: block;
            margin-bottom: 5px;
        }
        .form-group input {
            width: 100%;
            padding: 10px;
            border: 1px solid #ccc;
            border-radius: 4px;
        }
        .btn {
            width: 100%;
            padding: 10px;
            background-color: #5cb85c;
            color: white;
            border: none;
            border-radius: 4px;
            cursor: pointer;
        }
        .btn:hover {
            background-color: #4cae4c;
        }
    </style>
</head>
<body>

<div class="login-container">
    <h2>Login</h2>
    <?php if ($error_message): ?>
        <div class="error-message"><?php echo $error_message; ?></div>
    <?php endif; ?>
    <?php if ($success_message): ?>
        <div class="success-message"><?php echo $success_message; ?></div>
    <?php endif; ?>
    
    <form method="POST">
        <h3>Admin Login</h3>
        <div class="form-group">
            <label for="admin_email">Admin Email:</label>
            <input type="email" name="admin_email" id="admin_email" required>
        </div>
        <div class="form-group">
            <label for="admin_password">Admin Password:</label>
            <input type="password" name="admin_password" id="admin_password" required>
        </div>
        <button type="submit" name="admin_login" class="btn">Admin Login</button>
    </form>

    <h3>Customer Login</h3>
    <form method="POST">
        <div class="form-group">
            <label for="customer_email">Customer Email:</label>
            <input type="email" name="customer_email" id="customer_email" required>
        </div>
        <div class="form-group">
            <label for="customer_password">Customer Password:</label>
            <input type="password" name="customer_password" id="customer_password" required>
        </div>
        <button type="submit" name="customer_login" class="btn">Customer Login</button>
    </form>

    <h3>Register</h3>
    <form method="POST">
        <div class="form-group">
            <label for="customer_name">Customer Name:</label>
            <input type="text" name="customer_name" id="customer_name" required>
        </div>
        <div class="form-group">
            <label for="contact_name">Contact Name:</label>
            <input type="text" name="contact_name" id="contact_name" required>
        </div>
        <div class="form-group">
            <label for="address">Address:</label>
            <input type="text" name="address" id="address" required>
        </div>
        <div class="form-group">
            <label for="city">City:</label>
            <input type="text" name="city" id="city" required>
        </div>
        <div class="form-group">
            <label for="postal_code">Postal Code:</label>
            <input type="text" name="postal_code" id="postal_code" required>
        </div>
        <div class="form-group">
            <label for="country">Country:</label>
            <input type="text" name="country" id="country" required>
        </div>
        <div class="form-group">
            <label for="new_customer_email">Email:</label>
            <input type="email" name="new_customer_email" id="new_customer_email" required>
        </div>
        <div class="form-group">
            <label for="new_customer_password">Password:</label>
            <input type="password" name="new_customer_password" id="new_customer_password" required>
        </div>
        <button type="submit" name="register" class="btn">Register</button>
    </form>
</div>

</body>
</html>
