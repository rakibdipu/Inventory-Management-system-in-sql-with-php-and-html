<?php
session_start();
include('includes/db.php'); // Include database connection

// Check admin authentication
if (!isset($_SESSION['role']) || $_SESSION['role'] !== 'admin') {
    header('Location: index.php');
    exit;
}

// Delete supplier
if (isset($_GET['id'])) {
    $supplierID = $_GET['id'];

    // First, delete all products associated with this supplier
    $deleteProductsQuery = "DELETE FROM products WHERE SupplierID = ?";
    $stmt = $conn->prepare($deleteProductsQuery);
    $stmt->bind_param("i", $supplierID);

    if (!$stmt->execute()) {
        echo "Error deleting products: " . $conn->error;
        exit;
    }

    // Then, delete the supplier
    $deleteSupplierQuery = "DELETE FROM Suppliers WHERE SupplierID = ?";
    $stmt = $conn->prepare($deleteSupplierQuery);
    $stmt->bind_param("i", $supplierID);

    if ($stmt->execute()) {
        header('Location: view_suppliers.php?message=Supplier deleted successfully');
        exit;
    } else {
        echo "Error deleting supplier: " . $conn->error;
        exit;
    }
} else {
    header('Location: view_suppliers.php?error=No supplier ID provided');
    exit;
}
?>
