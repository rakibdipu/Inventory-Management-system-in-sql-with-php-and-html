<?php
// view_categories.php
session_start(); // Start the session
include('includes/db.php'); // Include the database connection

// Check if the user is logged in as an admin
if (!isset($_SESSION['role']) || $_SESSION['role'] !== 'admin') {
    header('Location: index.php'); // Redirect to login page if not an admin
    exit;
}

// Generate CSRF token
if (empty($_SESSION['csrf_token'])) {
    $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
}

// Handle pagination variables
$limit = 10; // Number of records per page
$page = isset($_GET['page']) && is_numeric($_GET['page']) && $_GET['page'] > 0 ? (int)$_GET['page'] : 1;
$offset = ($page - 1) * $limit;

// Handle search functionality
$search = isset($_GET['search']) ? htmlspecialchars(strip_tags(trim($_GET['search']))) : '';
$searchQuery = $search ? "WHERE CategoryName LIKE ? OR Description LIKE ?" : '';

// Handle sorting functionality
$orderBy = isset($_GET['order_by']) && in_array($_GET['order_by'], ['CategoryName', 'Description']) ? $_GET['order_by'] : 'CategoryName';
$sort = isset($_GET['sort']) && $_GET['sort'] === 'desc' ? 'DESC' : 'ASC';

// Fetch categories from the database
$query = "SELECT * FROM Categories $searchQuery ORDER BY $orderBy $sort LIMIT ? OFFSET ?";
$stmt = $conn->prepare($query);

if ($search) {
    $searchParam = "%$search%";
    $stmt->bind_param('ssii', $searchParam, $searchParam, $limit, $offset);
} else {
    $stmt->bind_param('ii', $limit, $offset);
}

if (!$stmt->execute()) {
    error_log('Database error: ' . $stmt->error);
    die('<p style="color:red;">Something went wrong. Please try again later.</p>');
}

$result = $stmt->get_result();

// Get the total number of records for pagination
$totalQuery = "SELECT COUNT(*) AS total FROM Categories $searchQuery";
$totalStmt = $conn->prepare($totalQuery);
if ($search) {
    $totalStmt->bind_param('ss', $searchParam, $searchParam);
}
$totalStmt->execute();
$totalResult = $totalStmt->get_result();
$totalRecords = $totalResult->fetch_assoc()['total'];
$totalPages = ceil($totalRecords / $limit);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Manage Categories - Amazon Bangladesh</title>
    <link rel="stylesheet" href="css/style.css"> <!-- Link to your CSS file -->
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f4f4f4;
            margin: 0;
            padding: 20px;
        }
        header {
            background: #007BFF;
            color: white;
            padding: 10px 20px;
            text-align: center;
        }
        nav ul {
            list-style: none;
            padding: 0;
        }
        nav ul li {
            display: inline;
            margin-right: 15px;
        }
        nav ul li a {
            color: white;
            text-decoration: none;
        }
        main {
            margin-top: 20px;
            padding: 20px;
            background: white;
            border-radius: 5px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
        }
        table {
            width: 100%;
            border-collapse: collapse;
        }
        table, th, td {
            border: 1px solid #ddd;
        }
        th, td {
            padding: 8px;
            text-align: left;
        }
        th {
            background-color: #007BFF;
            color: white;
        }
        footer {
            text-align: center;
            margin-top: 20px;
            font-size: 0.9em;
        }
        .pagination {
            margin-top: 10px;
            text-align: center;
        }
        .pagination a {
            margin: 0 5px;
            padding: 5px 10px;
            background: #007BFF;
            color: white;
            text-decoration: none;
            border-radius: 3px;
        }
        .pagination a.active {
            background: #0056b3;
        }
        .search-bar {
            margin-bottom: 15px;
        }
        .search-bar input {
            padding: 5px;
            width: 200px;
        }
        .add-category-btn {
            margin-bottom: 20px;
            display: inline-block;
            padding: 10px 15px;
            background-color: #28a745;
            color: white;
            text-decoration: none;
            border-radius: 5px;
        }
        .add-category-btn:hover {
            background-color: #218838;
        }
        .clear-search {
            margin-left: 10px;
            padding: 5px 10px;
            background-color: #6c757d;
            color: white;
            text-decoration: none;
            border-radius: 3px;
        }
        .clear-search:hover {
            background-color: #5a6268;
        }
    </style>
</head>
<body>
    <header>
        <h1>Manage Categories</h1>
        <nav>
            <ul>
                <li><a href="admin_dashboard.php">Dashboard</a></li>
                <li><a href="view_customers.php">Manage Customers</a></li>
                <li><a href="view_orders.php">View Orders</a></li>
                <li><a href="view_suppliers.php">Manage Suppliers</a></li>
                <li><a href="view_warehouse.php">Manage Warehouse</a></li>
                <li><a href="logout.php">Logout</a></li>
            </ul>
        </nav>
    </header>

    <main>
        <div class="search-bar">
            <form method="GET" action="">
                <input type="text" name="search" placeholder="Search by Category Name or Description" value="<?php echo htmlspecialchars($search); ?>">
                <button type="submit">Search</button>
                <a href="view_categories.php" class="clear-search">Clear</a>
            </form>
        </div>

        <div class="category-listing-container">
            <a href="add_category.php" class="add-category-btn">Add New Category</a>
            <?php if ($result->num_rows > 0): ?>
                <table>
                    <thead>
                        <tr>
                            <th>Category ID</th>
                            <th><a href="?order_by=CategoryName&sort=<?php echo $sort === 'ASC' ? 'desc' : 'asc'; ?>&search=<?php echo urlencode($search); ?>">Category Name</a></th>
                            <th><a href="?order_by=Description&sort=<?php echo $sort === 'ASC' ? 'desc' : 'asc'; ?>&search=<?php echo urlencode($search); ?>">Description</a></th>
                            <th>Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php while ($row = $result->fetch_assoc()): ?>
                            <tr>
                                <td><?php echo htmlspecialchars($row['CategoryID']); ?></td>
                                <td><?php echo htmlspecialchars($row['CategoryName']); ?></td>
                                <td><?php echo htmlspecialchars($row['Description']); ?></td>
                                <td>
                                    <a href="edit_category.php?id=<?php echo $row['CategoryID']; ?>">Edit</a> |
                                    <form method="POST" action="delete_category.php" style="display:inline;">
                                        <input type="hidden" name="id" value="<?php echo $row['CategoryID']; ?>">
                                        <input type="hidden" name="csrf_token" value="<?php echo $_SESSION['csrf_token']; ?>">
                                        <button type="submit" onclick="return confirm('Are you sure you want to delete this category?');">Delete</button>
                                    </form>
                                </td>
                            </tr>
                        <?php endwhile; ?>
                    </tbody>
                </table>
            <?php else: ?>
                <p>No categories found.</p>
            <?php endif; ?>
        </div>

        <div class="pagination">
            <?php for ($i = 1; $i <= $totalPages; $i++): ?>
                <a href="?page=<?php echo $i; ?>&search=<?php echo urlencode($search); ?>" class="<?php echo $i === $page ? 'active' : ''; ?>">
                    <?php echo $i; ?>
                </a>
            <?php endfor; ?>
        </div>
    </main>

    <footer>
        <p>&copy; <?php echo date("Y"); ?> Amazon Bangladesh. All rights reserved.</p>
    </footer>
</body>
</html>
