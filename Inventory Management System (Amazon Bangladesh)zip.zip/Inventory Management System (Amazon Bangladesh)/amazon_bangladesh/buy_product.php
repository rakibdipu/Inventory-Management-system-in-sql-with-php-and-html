<?php
session_start();
include('includes/db.php'); // Include the database connection

// Check if the user is logged in as a customer
if (!isset($_SESSION['role']) || $_SESSION['role'] !== 'customer') {
    header('Location: index.php'); // Redirect if not logged in
    exit;
}

// Check if product ID is provided
if (isset($_POST['product_id'])) {
    $productID = $_POST['product_id'];
    $customerID = $_SESSION['customer_id']; // Get the logged-in customer ID

    // Fetch product details
    $query = "SELECT * FROM Products WHERE ProductID = ?";
    $stmt = $conn->prepare($query);
    $stmt->bind_param("i", $productID);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result->num_rows > 0) {
        $product = $result->fetch_assoc();

        // Insert the order into the Orders table
        $orderQuery = "INSERT INTO Orders (CustomerID, OrderDate, TotalAmount) VALUES (?, NOW(), ?)";
        $stmt = $conn->prepare($orderQuery);
        $stmt->bind_param("id", $customerID, $product['Price']);
        $stmt->execute();

        if ($stmt->affected_rows > 0) {
            // Success Message
            $message = "Buying successful. Product will reach your destination within 3 days. Payment method:Cash on delivery  . For queries, phone: 98887775551430.";
        } else {
            // Error Message
            $message = "Error placing the order. Please try again.";
        }
    } else {
        $message = "Product not found.";
    }
} else {
    header('Location: customer_dashboard.php'); // Redirect if no product ID
    exit;
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Purchase Confirmation</title>
    <link rel="stylesheet" href="css/style.css"> <!-- Link to your CSS file -->
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f4f4f4;
            margin: 0;
            padding: 20px;
            text-align: center;
        }
        .message-container {
            background-color: white;
            border: 1px solid #ddd;
            padding: 20px;
            margin: 50px auto;
            max-width: 600px;
            border-radius: 5px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
        }
        .success-message {
            color: green;
            font-size: 18px;
            margin-bottom: 15px;
        }
        .error-message {
            color: red;
            font-size: 18px;
            margin-bottom: 15px;
        }
        a {
            text-decoration: none;
            color: #007BFF;
        }
        a:hover {
            text-decoration: underline;
        }
    </style>
</head>
<body>
    <div class="message-container">
        <?php if (isset($message)): ?>
            <p class="<?= strpos($message, 'successful') !== false ? 'success-message' : 'error-message'; ?>">
                <?= htmlspecialchars($message); ?>
            </p>
        <?php endif; ?>
        <a href="customer_dashboard.php">Go back to Dashboard</a>
    </div>
</body>
</html>
